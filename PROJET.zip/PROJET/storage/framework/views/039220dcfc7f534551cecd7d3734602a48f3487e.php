<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/bootstrap.min.css")); ?>">
    <title>Document</title>
</head>

<body>
    <ul class="nav justify-content-end">
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(route("welcome")); ?>">
                <button type="button" class="btn btn-outline-warning">Accueil</button>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route("accueil")); ?>">
                <button type="button" class="btn btn-primary">Ajouter une voiture</button>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route("Reparateur")); ?>">
                <button type="button" class="btn btn-outline-info">Ajouter un réparateur</button>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route("reparations")); ?>">
                <button type="button" class="btn btn-outline-primary">Reparations</button>
            </a>

    </ul><br>
    <h1>Reparations</h1>

    <form>
        <div class="mb-3">
            <label for="atelier" class="form-label">Véhicules</label>
            <select class="form-select form-select-lg mb-3">
                <option value="" selected>Choisir un véhicule</option>
                <?php $__currentLoopData = $ateliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atelier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($atelier->id); ?>"><?php echo e($atelier->immatriculation); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="Reparateur" class="form-label">Techniciens</label>
            <select class="form-select form-select-lg mb-3">
                <option value="" selected>Choisir un technicien</option>
                <?php $__currentLoopData = $Reparateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Reparateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($Reparateur->nom); ?>"><?php echo e($Reparateur->nom); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="date" class="form-label">Date</label>
            <input type="date" class="form-control" id="date" name="date" placeholder="Date de réparations">
        </div>

        <div class="mb-3">
            <label for="duree" class="form-label">Durée de main d'oeuvre</label>
            <input type="text" class="form-control" id="duree" name="duree" placeholder="Date de réparations">
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>



    <script src=<?php echo e(asset("assets/js/bootstrap.min.js")); ?>></script>
</body>

</html><?php /**PATH C:\Users\USER\PROJET\resources\views/reparations.blade.php ENDPATH**/ ?>