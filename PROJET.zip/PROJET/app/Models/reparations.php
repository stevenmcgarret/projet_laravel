<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class reparations extends Model
{
    use HasFactory;
    protected $fillable = [
        "atelier_id",
        "Reparateur",
        "date",
        "duree_main_oeuvre",
        "objet_reparation"
    ];
}
