<?php

namespace App\Http\Controllers;

use App\Models\atelier;
use App\Models\Reparateur;
use Illuminate\Http\Request;

class ReparationsController extends Controller
{
    //
    public function reparations() {
        $ateliers = Atelier::all();
        $Reparateurs = Reparateur::all();
        
        return view("reparations", compact("ateliers", "Reparateurs"));
    }
}